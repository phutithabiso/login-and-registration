/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registerandlogin;

import java.util.Scanner;


public class Registerandlogin {

    /**
     * @param args the command line arguments
     */
      // declare thevariables 
    
 //object of method class containing all method to check conditions
    static methodclass method= new methodclass();
      public static String firstname ="";
     public static String lastname="";
     public  static String username="";
     public  static String password="";
     public static String loginusername="";
     public static String loginpassword="";
     
    
    public static void main(String[] args) { 
        Scanner scan =new Scanner(System.in);
        register se = new register(firstname,lastname,username,password,loginusername,loginpassword);
    // Creating an instance of the Register class with the user input
    
         System.out.println("----------------------");
         System.out.println("****Registration******");
         System.out.println("----------------------");
         //promoting the user to enter there information
         System.out.println("ENTER FIRST NAME:");
           String firstname = scan.nextLine();
         
         System.out.println("ENTER LAST NAME:");
         lastname = scan.nextLine();
         
          //while loop to check if the username is correct
          
          do{
               System.out.println("ENTER USERNAME:");
              username = scan.nextLine();
          
          }while( method.checkUsername(username)!=true);
             
              boolean found =false;
            
          //while loop to check if the password is correct
          do{
             System.out.println("ENTER PASSWORD:");
               password=scan.nextLine();
          }while(method.checkPasswordComplexity(password)!=true);
             
            
     //while loop to continue checking and asking the user input the info
        do{
             System.out.print("---------------------\n");
            System.out.print("\n *****LOGIN******\n");
            System.out.print("---------------------\n");
            System.out.print("ENTER USERNAME: ");
            loginusername= scan.nextLine();
            
            System.out.print("ENTER PASSWORD: ");
            loginpassword= scan.nextLine();
            
        }while(method.loginUser(loginusername,loginpassword)!=true);
    }
    
    
}
