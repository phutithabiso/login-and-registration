/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package registerandlogin;
import java.util.regex.Pattern;
/**
 *
 * @author Mahlatse Phaka
 */
//object of method class containing all method to check conditions
   
public class methodclass {
   
     public static boolean checkUsername(String username) {
    boolean check = false;
    if (username.length() == 5 && username.contains("_")) {
        check = true;
        System.out.println("***");
        System.out.println("Username successfully captured");
        System.out.println("***");
    } else {
        System.out.println("***");
        System.out.println("Username incorrect");
        System.out.println("***");
    }
    return check;
}
   public static boolean checkPasswordComplexity(String password) {
    if (password == null || password.length() < 8) {
        return false;
    }

    boolean hasCapitalLetter = false;
    boolean hasNumber = false;
    boolean hasSpecial = false;
    
    for (char v : password.toCharArray()) {
        if (Character.isUpperCase(v)) {
            hasCapitalLetter = true;
        } else if (Character.isDigit(v)) {
            hasNumber = true;
        } else if (!Character.isLetterOrDigit(v)) {
            hasSpecial = true;
        }
    }

    return hasCapitalLetter && hasNumber && hasSpecial;
}
 public static String registerUser(String username, String password) {
    boolean hasUsername = checkUsername(username);
    boolean hasPasswords= checkPasswordComplexity(password);

    if (hasUsername && hasPasswords) {
        return "User successfully registered";
    } else if (!hasUsername) {
        return "Username is incorrectly formatted";
    } else {
        return "Password does not meet the complexity requirements";
    } 
 }
 boolean loginUser(String loginusername, String loginpassword) {
    boolean found = false;

      //validating or checking user information before login
        if( Registerandlogin.password.equals(loginpassword)&& Registerandlogin.username.equals(loginusername)){
            
            //assigning
            found = true;
            returnLoginstatus(found);    
            return true;
        }
        //if password correct but username not correct
        else if( Registerandlogin.password.equals(loginpassword)&&! Registerandlogin.username.equals(loginusername)){
            
            //assigning
            found = false;
            returnLoginstatus(found);
            return false;
        } 
        //if username correct but password not correct
        else if(! Registerandlogin.password.equals(loginpassword)& Registerandlogin.username.equals(loginusername)){
            
            //assigning
            found = false;
            returnLoginstatus(found);
            return false;
        }   
        return false;
        
        
 }
 //method to return login user message
    static  String returnLoginstatus(boolean founds){
        if(founds){
            //displaying message of login successfully
            System.out.println("Login successfully\n"
                 +"Welcome "+ Registerandlogin.firstname+", "+ Registerandlogin.lastname
                +"\nit is great to see you\n");
        }else if(!founds){
            //displaying message error message
            System.out.println(" username or password incorrect please try again");
            
           
        }
        
        return null;
        
    } 
    }
  
 
 
